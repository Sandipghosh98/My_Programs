// Programming Question.
#include<iostream>
using namespace std;

int main()
{
    int _5,_10,_20;
    
}