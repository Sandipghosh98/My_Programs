#include<stdio.h>

int main()
{
    int num,fact;
    cin>>num;
    int i;
    for(i=num;i>0;i--) {

    }
}