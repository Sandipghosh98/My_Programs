/*
    Q.) Find all the prime number before n?
*/