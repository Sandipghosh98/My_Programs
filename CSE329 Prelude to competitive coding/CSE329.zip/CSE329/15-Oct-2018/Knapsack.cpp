#include <bits/stdc++.h>
using namespace std;

struct Knapsack {
    int value,weight;
};

int main()
{
    Knapsack arr[] = { {10, 10}, {50, 2} }

    return 0;
}

/*
100 50 120 200
10 20 30 5
*/